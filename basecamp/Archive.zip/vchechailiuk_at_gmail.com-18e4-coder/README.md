The list of files which are allowed to be modified:
    project/coder.cpp
    project/coder.h
    Makefile

Other files will be restored on Jenkins CI side before each build.
